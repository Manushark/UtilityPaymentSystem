﻿namespace UtilityPaymentSystem.Domain
{
    public class Class1
    {

    }
}
